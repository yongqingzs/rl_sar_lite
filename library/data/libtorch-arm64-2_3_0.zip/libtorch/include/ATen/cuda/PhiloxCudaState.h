#pragma once

#include <cstdint>

#include <ATen/cuda/detail/PhiloxCudaStateRaw.cuh>
